n = int(input())
print(max(map(int, input().split())))
