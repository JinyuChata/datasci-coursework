a = int(input())
b=[]

for i in range(a):
    b.append(int(input()))
for c in b:
    print(((c*c)*2)+c)
    