### 题目描述
给定字符串s，任务是计算aibjck形式的子序列数，其中i> = 1，j> = 1，k> = 1。 

注意：如果为两个子序列选择的数组索引集不同，则两个子序列被认为是不同的。
### 输入描述
输入的第一行包含一个整数T，表示测试用例的数量。然后是T测试用例。每个测试用例都包含一个字符串s。
### 输出描述
对于换行中的每个测试用例，请打印所需的输出。
### 输入范例
```
2
abbc
abcabc
```
### 输出范例
```
3
7
```
abbc子串为abc, abc and abbc
abcabc子串为abc, abc, abbc, aabc abcc, abc and abc
### 题目来源
geeksforgeeks.org
