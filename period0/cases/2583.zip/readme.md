### 题目描述
<p>请你帮忙设计一个程序，用来找出第&nbsp;<code>n</code>&nbsp;个丑数。</p>

<p>丑数是可以被&nbsp;<code>a</code>&nbsp;<strong>或</strong>&nbsp;<code>b</code>&nbsp;<strong>或</strong> <code>c</code>&nbsp;整除的 <strong>正整数</strong>。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>n = 3, a = 2, b = 3, c = 5
<strong>输出：</strong>4
<strong>解释：</strong>丑数序列为 2, 3, 4, 5, 6, 8, 9, 10... 其中第 3 个是 4。</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>n = 4, a = 2, b = 3, c = 4
<strong>输出：</strong>6
<strong>解释：</strong>丑数序列为 2, 3, 4, 6, 8, 9, 12... 其中第 4 个是 6。
</pre>

<p><strong>示例 3：</strong></p>

<pre><strong>输入：</strong>n = 5, a = 2, b = 11, c = 13
<strong>输出：</strong>10
<strong>解释：</strong>丑数序列为 2, 4, 6, 8, 10, 11, 12, 13... 其中第 5 个是 10。
</pre>

<p><strong>示例 4：</strong></p>

<pre><strong>输入：</strong>n = 1000000000, a = 2, b = 217983653, c = 336916467
<strong>输出：</strong>1999999984
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>1 &lt;= n, a, b, c &lt;= 10^9</code></li>
	<li><code>1 &lt;= a * b * c &lt;= 10^18</code></li>
	<li>本题结果在&nbsp;<code>[1,&nbsp;2 * 10^9]</code>&nbsp;的范围内</li>
</ul>
### 样例输入<br>
```
3
2
3
5
```
### 样例输出<br>
```
4
```
### 题目来源  
`LeetCode`