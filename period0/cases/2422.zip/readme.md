### 题目描述

<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%BF%AB%E9%80%9F%E6%8E%92%E5%BA%8F.png" alt="Sample"  width="750" height="87">
</p>

### 输入描述

<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%BF%AB%E9%80%9F%E6%8E%92%E5%BA%8F2.png" alt="Sample"  width="300" height="36">
</p>

<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%BF%AB%E9%80%9F%E6%8E%92%E5%BA%8F4.png" alt="Sample"  width="420" height="37">
</p>

### 输出描述

<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%BF%AB%E9%80%9F%E6%8E%92%E5%BA%8F3.png" alt="Sample"  width="800" height="47">
</p>

### 测试样例
#### 样例1: 输入-输出-解释
```
5
3 1 4 2 5
```
```
1
1 5
```
#### 样例2: 输入-输出-解释
```
8
2 4 1 5 3 6 7 8
```
```
2
2 6
1 2
```
### 题目来源  
`ROI 2018 Day 2`