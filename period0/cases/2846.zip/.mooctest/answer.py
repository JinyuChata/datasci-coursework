n, a = int(input()), set(map(int, input().split()))
print(len(a) - (0 in a))
