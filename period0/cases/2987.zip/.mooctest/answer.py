x=input()
a=x[::-1]
print(x+a)