### 题目描述

<p align="left">
 <img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/tree/%E8%8B%B9%E6%9E%9C%E6%A0%91.png" alt="Sample"  width="1000" height="150">
</p >

### 输入描述

<p align="left">
 <img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/tree/%E8%8B%B9%E6%9E%9C%E6%A0%911.png" alt="Sample"  width="1000" height="70">
</p >


### 输出描述

<p align="left">
 <img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/tree/%E8%8B%B9%E6%9E%9C%E6%A0%912.png" alt="Sample"  width="1000" height="55">
</p >



### 测试样例
#### 样例1:输入-输出-解释

```
2
5 1
0 1 1
1 1 1
1 1 3
2 1 10
3 1 4
9 15
0 1 1
1 7 2
2 5 10
1 3 1
4 3 17
4 3 18
4 4 19
1 1 1
8 1 100
```
```
15
316
```
```
无
```
#### 样例2: 输入-输出-解释
```
3
3 1
0 1 1
1 1 1
1 1 3
7 20
0 1 1
1 7 2
2 5 10
1 3 1
4 3 17
4 3 18
4 4 19
5 1
0 1 1
1 1 1
1 1 3
2 1 10
3 1 4
```
```
5
245
15
```
```
无
```
### 题目来源  
`loj.ac`