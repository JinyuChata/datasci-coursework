def JQ(a,b):
    a=a[b:len(a)+1]
    print(a)
n=int(input())
x=input()
m=int(input())-1
JQ(x,m)