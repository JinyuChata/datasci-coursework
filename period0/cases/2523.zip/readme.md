### 题目描述

给你一个 m * n 的整数矩阵 mat ，请你将同一条对角线上的元素（从左上到右下）按升序排序后，返回排好序的矩阵。

m == mat.length

n == mat[i].length

1 <= m, n <= 100

1 <= mat[i][j] <= 100

### 输入描述

```
一个 m * n 的整数矩阵 mat
```
### 输出描述

```
返回排好序的矩阵
```

### 测试样例
#### 样例1: 输入-输出-解释
```
[[3,3,1,1],[2,2,1,2],[1,1,1,2]]
```
```
[[1,1,1,1],[1,2,2,2],[1,2,3,3]]
```

<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E5%B0%86%E7%9F%A9%E9%98%B5%E6%8C%89%E5%AF%B9%E8%A7%92%E7%BA%BF%E6%8E%92%E5%BA%8F.png" alt="Sample"  width="375" height="140">
</p>

### 题目来源  
`LeetCode`