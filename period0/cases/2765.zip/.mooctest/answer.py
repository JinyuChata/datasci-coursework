for i in range(int(input())):
    P=int(input())
    R=int(input())
    T=int(input())
    S=(P*R*T)//100
    print(S)
