n = int(input())
a = sorted(map(int, input().split()))
print(a[(n-1)//2])
