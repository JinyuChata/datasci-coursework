### 题目描述
<p>回旋镖定义为一组三个点，这些点各不相同且<strong>不</strong>在一条直线上。</p>

<p>给出平面上三个点组成的列表，判断这些点是否可以构成回旋镖。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>[[1,1],[2,3],[3,2]]
<strong>输出：</strong>True
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>[[1,1],[2,2],[3,3]]
<strong>输出：</strong>False</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>points.length == 3</code></li>
	<li><code>points[i].length == 2</code></li>
	<li><code>0 &lt;= points[i][j] &lt;= 100</code></li>
</ol>
### 样例输入<br>
```
3
1,1
2,3
3,2
```
### 样例输出<br>
```
True
```
```
第一行N是二维列表长度，接下来N行是N个点的坐标
```
### 题目来源  
`LeetCode`
