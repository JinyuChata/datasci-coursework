t=int(input())
while t:
    t=t-1
    n=int(input())
    if n%2:
        print("Player A")
    else:
        print("Player B")