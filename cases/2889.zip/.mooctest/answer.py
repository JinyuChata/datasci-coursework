n = int(input())
print("{:.6f}".format(sum(map(int, input().split()))/n))
