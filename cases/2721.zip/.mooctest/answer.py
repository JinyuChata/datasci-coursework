for t in range(int(input())):
    a,b = [int(x, 2) for x in input().split()]
    print(a*b)