for t in range(int(input())):
    print((int(input()) + (1 << 32))^((1 << 33)-1) )