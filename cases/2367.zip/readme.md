### 题目描述
<p>给定正整数&nbsp;<code>K</code>，你需要找出可以被 K 整除的、仅包含数字 <strong>1</strong> 的最小正整数 N。</p>

<p>返回&nbsp;<code>N</code>&nbsp;的长度。如果不存在这样的&nbsp;<code>N</code>，就返回 <code>-1</code>。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>1
<strong>输出：</strong>1
<strong>解释：</strong>最小的答案是 N = 1，其长度为 1。</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>2
<strong>输出：</strong>-1
<strong>解释：</strong>不存在可被 2 整除的正整数 N 。</pre>

<p><strong>示例 3：</strong></p>

<pre><strong>输入：</strong>3
<strong>输出：</strong>3
<strong>解释：</strong>最小的答案是 N = 111，其长度为 3。</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>1 &lt;= K &lt;= 10^5</code></li>
</ul>
### 样例输入<br>
```
1
```
### 样例输出<br>
```
1
```
### 题目来源  
`LeetCode`
