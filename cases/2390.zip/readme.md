### 题目描述

<p align="center">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E6%8E%92%E5%BA%8F%E4%BA%A4%E6%8D%A2.png" alt="Sample"  width="800" height="125">
</p>

### 输入描述

第一行一个整数n。

第二行2<sup>n</sup>个整数，表示A[1...2<sup>n</sup>]。

数据范围：1≤N≤12
### 输出描述

```
一个整数表示答案。
```

### 测试样例
#### 样例1:输入-输出-解释

```
3
7 8 5 6 1 2 4 3
```
```
6
```

### 题目来源  
`SDOI`