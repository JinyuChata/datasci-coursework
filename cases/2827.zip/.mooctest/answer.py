n = int(input())
print(*sorted(map(int, input().split())))
