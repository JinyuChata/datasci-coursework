t = int(input())
while t:
    t-=1
    n = int(input())
    
    if(n%5==0):
        print("-1")
    else:
        print(n%5)