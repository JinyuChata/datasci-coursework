### 题目描述

<p align="left">
 <img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/tree/%E8%90%A5%E4%B8%9A%E9%A2%9D%E7%BB%9F%E8%AE%A1.png" alt="Sample"  width="600" height="300">
</p >

### 输入描述

<p align="left">
 <img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/tree/%E8%90%A5%E4%B8%9A%E9%A2%9D%E7%BB%9F%E8%AE%A11.png" alt="Sample"  width="350" height="60">
</p >
### 输出描述

<p align="left">
 <img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/tree/%E8%90%A5%E4%B8%9A%E9%A2%9D%E7%BB%9F%E8%AE%A12.png" alt="Sample"  width="330" height="35">
</p >

### 测试样例
#### 样例1:输入-输出-解释

```
6
5
1
2
5
4
6
```
```
12
```
```
5+|1-5|+|2-1|+|5-5|+|4-5|+|6-5|=5+4+1+0+1+1=12
```

### 题目来源  
`luogu.com.cn`