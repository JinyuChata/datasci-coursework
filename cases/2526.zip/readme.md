### 题目描述

给你 root1 和 root2 这两棵二叉搜索树。

请你返回一个列表，其中包含 两棵树 中的所有整数并按 升序 排序。

### 输入描述

```
root1 和 root2 两棵二叉搜索树
```
### 输出描述

```
返回按升序排序的序列
```

### 测试样例
#### 样例1: 输入-输出-解释
```
[2,1,4]
[1,0,3]
```
```
[0,1,1,2,3,4]
```
<p align="">
	<img src="http://mooctest-code.oss-cn-shanghai.aliyuncs.com/static/media/%E4%B8%A4%E6%A3%B5%E4%BA%8C%E5%8F%89%E6%90%9C%E7%B4%A2%E6%A0%91%E4%B8%AD%E7%9A%84%E6%89%80%E6%9C%89%E5%85%83%E7%B4%A0.png" alt="Sample"  width="390" height="140">
</p>

### 题目来源  
`LeetCode`