### 题目描述
<p>给定一个由 4 位数字组成的数组，返回可以设置的符合 24 小时制的最大时间。</p>

<p>最小的 24 小时制时间是&nbsp;00:00，而最大的是&nbsp;23:59。从 00:00 （午夜）开始算起，过得越久，时间越大。</p>

<p>以长度为 5 的字符串返回答案。如果不能确定有效时间，则返回空字符串。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><strong>输入：</strong>[1,2,3,4]
<strong>输出：</strong>"23:41"
</pre>

<p><strong>示例 2：</strong></p>

<pre><strong>输入：</strong>[5,5,5,5]
<strong>输出：</strong>""
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ol>
	<li><code>A.length == 4</code></li>
	<li><code>0 &lt;= A[i] &lt;= 9</code></li>
</ol>
### 样例输入<br>
```
1,2,3,4
```
### 样例输出<br>
```
23:41
```
### 题目来源
`LeetCode`