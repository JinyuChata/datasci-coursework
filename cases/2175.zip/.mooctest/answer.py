print('0 1')
print('1 3')
print('1 2')
# print('4 3')