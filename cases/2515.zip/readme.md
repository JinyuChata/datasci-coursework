### 题目描述
<p>给定一个非负整数数组和一个整数&nbsp;<em>m</em>，你需要将这个数组分成&nbsp;<em>m&nbsp;</em>个非空的连续子数组。设计一个算法使得这&nbsp;<em>m&nbsp;</em>个子数组各自和的最大值最小。</p>

<p><strong>注意:</strong><br>
数组长度&nbsp;<em>n&nbsp;</em>满足以下条件:</p>

<ul>
	<li>1 ≤ <em>n</em> ≤ 1000</li>
	<li>1 ≤ <em>m</em> ≤ min(50, <em>n</em>)</li>
</ul>

<p><strong>示例: </strong></p>

<pre>输入:
<strong>nums</strong> = [7,2,5,10,8]
<strong>m</strong> = 2

输出:
18

解释:
一共有四种方法将<strong>nums</strong>分割为2个子数组。
其中最好的方式是将其分为<strong>[7,2,5]</strong> 和 <strong>[10,8]</strong>，
因为此时这两个子数组各自的和的最大值为18，在所有情况中最小。
</pre>
### 样例输入<br>
```
7,2,5,10,8
2
```
### 样例输出<br>
```
18
```
### 题目来源  
`LeetCode`