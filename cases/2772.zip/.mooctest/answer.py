import math
for _ in range(int(input())):
    print(math.floor(int(input())**(1/3)))