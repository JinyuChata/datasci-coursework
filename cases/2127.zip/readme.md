## 题目描述
<p>你的任务是计算&nbsp;<em>a</em><sup><em>b</em></sup>&nbsp;对&nbsp;1337 取模，<em>a</em> 是一个正整数，<em>b</em> 是一个非常大的正整数且会以数组形式给出。</p>

<p><strong>示例 1:</strong></p>

<pre><strong>输入: </strong>a = 2, b = [3]
<strong>输出: </strong>8
</pre>

<p><strong>示例&nbsp;2:</strong></p>

<pre><strong>输入: </strong>a = 2, b = [1,0]
<strong>输出: </strong>1024</pre>