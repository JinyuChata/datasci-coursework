for t in range(int(input())):
    x,g = [int(x) for x in input().split()]
    print(-x+g-1)