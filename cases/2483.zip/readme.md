### 题目描述
给定一个字符串str和另一个字符串patt。在str中的最小索引处找到patt中的字符。如果str中不存在patt字符，则打印$
### 输入描述
输入的第一行包含一个整数T，表示测试用例的数量。然后是T测试用例的描述。每个测试用例分别包含两个字符串str和patt。
### 输出描述
输出出现在str最小索引处的patt字符。如果str中没有patt字符，则打印“ $”（不带引号）。
### 输入范例
```
2
geeksforgeeks
set
adcffaet
onkl
```
### 输出范例
```
e
$
```
### 题目来源
geeksforgeeks.org

