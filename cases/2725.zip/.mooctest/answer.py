for t in range(int(input())):
    n = int(input())
    if(n%2 == 0):
        print("1")
    else:
        print("0")